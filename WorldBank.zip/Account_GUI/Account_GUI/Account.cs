﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Account_GUI
{
    public abstract class Account
    {
        public readonly List<Person> holders = new List<Person>();
        public readonly List<Transaction> transactions = new List<Transaction>();
        public readonly string Number;
        private static int LAST_NUMBER = 100000;

        public double Balance { get; protected set; }
        public double LowestBalance { get; protected set; }


        public Account(string type, double balance)
        {
            this.Balance = balance;
            this.LowestBalance = balance;
            this.Number = type + Convert.ToString(LAST_NUMBER);
            LAST_NUMBER++;
        }

        public string GetAccountType()
        {
            string ret = "";
            string accountType = this.Number.Substring(0, 2);
            if (accountType == "VS")
            {
                ret = "Visa";
            }
            else if (accountType == "CK")
            {
                ret = "Checking";
            }
            else if (accountType == "SV")
            {
                ret = "Savings";
            }

            return ret;
        }

        public void AddUser(Person person)
        {
            holders.Add(person);
        }


        public void Deposit(double amount, Person person)
        {
            Balance += amount;
            LowestBalance = Balance < LowestBalance ? Balance : LowestBalance;
            Transaction t1 = new Transaction(Number, amount, Balance, person, DateTime.Now);
            transactions.Add(t1);
        }


        public bool IsHolder(string name)
        {
            bool isHolder = false;

            foreach (Person h in holders)
            {
                if (name == h.Name)
                {
                    isHolder = true;
                    break;
                }
            }

            return isHolder;
        }


        public abstract void PrepareMonthlyReport();
        

        public override string ToString()
        {
            string formatString = "";
            string holdersString = "";
            string transactionsString = "";
            int counter = 0;

            for ( counter = 0; counter < holders.Count; counter++)
            {
                string name = holders[counter].Name;
                holdersString += name + (counter < holders.Count - 1 ? ", " : "");
            }

            for ( counter = 0; counter < transactions.Count; counter++)
            {
                Transaction t = transactions[counter];
                transactionsString += Convert.ToString(counter+1) + ") " + t + (counter < transactions.Count - 1 ? "\n" : "");
            }

            formatString = String.Format("Account: {0} | Balance: {1:C4}\nHolders: [{2}]\nTransactions:\n[\n{3}\n]\n", Number, Balance, holdersString, transactionsString);

            return formatString;
        }
    }
}
