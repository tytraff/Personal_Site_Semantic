﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form1 : Form
    {
        public static string username { get; private set; }
        public static string password { get; private set; }

        public Person currentUser = null; 

        public Form1()
        {
            InitializeComponent();
        }


        private void btnlogin_Click(object sender, EventArgs e)
        {
            bool personExists = false;
            bool isCorrectPassword = false;

            username = txtUser.Text;
            password = txtPass.Text;

            personExists = checkPersonExists();

            if (personExists)
            {
                isCorrectPassword = checkPassword();

                if (isCorrectPassword)
                {
                    this.Hide();
                    Form2 f2 = new Form2(currentUser);
                    Close();
                    f2.Show();

                }
                else
                {
                    MessageBox.Show("Incorrect Password");
                }
            }
            else
            {
                MessageBox.Show("User does not exist");
            }
        }

        private bool checkPersonExists()
        {
            bool personExists = false;

            try
            {
                currentUser = Bank.GetPerson(Form1.username);
                personExists = true;
            }
            catch
            {
                personExists = false;
            }

            return personExists;
        }


        private bool checkPassword()
        {
            bool isCorrectPassword = false;

            try
            {
                currentUser.Login(password);
                isCorrectPassword = true;
            }
            catch
            {
                isCorrectPassword = false;
            }

            return isCorrectPassword;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3(this);
            this.Enabled = false;
            f3.Show();
        }
    }
}
