﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form6 : Form
    {
        private Form2 mainF = null;

        Person CurrentUser = null;
        Account CurrentAccount = null;

        public Form6(Form2 mainForm, Person currentUser, Account currentAccount)
        {
            CurrentUser = currentUser;
            CurrentAccount = currentAccount;
            mainF = mainForm;
            InitializeComponent();

            updateAccount();
        }


        private void updateAccount()
        {
            List<string> accounts = new List<string>();
            accounts.Add(CurrentAccount.Number);
            cBoxAccounts.DataSource = null;
            cBoxAccounts.DataSource = accounts;
        }

        private void closeForm()
        {
            mainF.Enabled = true;
            this.Close();
        }


        private void btnDeposit_Click(object sender, EventArgs e)
        {
            double amount = Convert.ToDouble(numericAmount.Value);
            Console.WriteLine(amount);
            string accountType = CurrentAccount.GetAccountType();

            if (accountType == "Visa")
            {
                VisaAccount v = (VisaAccount)CurrentAccount;
                try
                {
                    v.DoPayment(amount, CurrentUser);
                    MessageBox.Show("Made a payment of " + String.Format("{0:C}", amount));
                    closeForm();
                }
                catch (AccountException exc)
                {
                    MessageBox.Show(exc.Message);
                }
            }
            else if (accountType == "Checking")
            {
                CheckingAccount c = (CheckingAccount)CurrentAccount;
                try
                {
                    c.Deposit(amount, CurrentUser);
                    MessageBox.Show("Deposited " + String.Format("{0:C}", amount));
                    closeForm();
                }
                catch (AccountException exc)
                {
                    MessageBox.Show(exc.Message);
                }
            }
            else if (accountType == "Savings")
            {
                SavingAccount s = (SavingAccount)CurrentAccount;
                try
                {
                    s.Deposit(amount, CurrentUser);
                    MessageBox.Show("Deposited " + String.Format("{0:C}", amount));
                    closeForm();
                }
                catch (AccountException exc)
                {
                    MessageBox.Show(exc.Message);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            closeForm();
        }
    }
}
