﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form2 : Form
    {
        public static double Chequeing { get; private set; }
        public static double Savings { get; private set; }
        public static double Visa { get; private set; }

        public Person CurrentUser = null;
        public Account currentAccount = null;
        Dictionary<string, Account> currentUserAccountsDict;
        bool isReturningToLogin = false;
        //p.Login(Form1.password);
        
        public Form2(Person currentUser)
        {
            CurrentUser = currentUser;
            InitializeComponent();
            updateUserLabels();
            updateListOfAccounts();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Close();
            //if(e.CloseReason)
            //Console.WriteLine(e.CloseReason);
            if (!isReturningToLogin)
            {
                Application.Exit();
            }
            else
            {
                isReturningToLogin = false;
            }
            
        }

        private void picLogout_Click(object sender, EventArgs e)
        {
            Form1 formMain = new Form1();
            formMain.Show();
            isReturningToLogin = true;
            Close();
        }


        private void cboxAccounts_SelectedValueChanged(object sender, EventArgs e)
        {
            string accountName = cboxAccounts.SelectedItem.ToString();
            Account selectedAccount = currentUserAccountsDict[accountName];
            currentAccount = selectedAccount;
            updateAccountLabels();
            updateTransactions();
            updateHolders();
        }


        public void updateTransactions()
        {
            List<Transaction> currentUserTransactions = new List<Transaction>();
            dataGridTransactions.DataSource = null;

            if (currentAccount != null)
            {
                dataGridTransactions.DataSource = currentAccount.transactions;
            }
        }


        public void updateHolders()
        {
            List<Person> currentUserHolders = new List<Person>();
            dataGridHolders.DataSource = null;

            if (currentAccount != null)
            {
                foreach (Person p in currentAccount.holders)
                {
                    //currentUserHolders.Add(
                }
                dataGridHolders.DataSource = currentAccount.holders;
            }
        }


        public void updateListOfAccounts()
        {
            List<Account> currentUserAccounts = new List<Account>();
            List<string> currentUserAccountsNames = new List<string>();
            currentUserAccountsDict = new Dictionary<string, Account>();

            cboxAccounts.DataSource = null;

            try
            {
                currentUserAccounts = Bank.getAllAccountsByHolder(CurrentUser);
                foreach (Account a in currentUserAccounts)
                {
                    currentUserAccountsNames.Add(a.Number);
                    currentUserAccountsDict.Add(a.Number, a);
                }
                cboxAccounts.DataSource = currentUserAccountsNames;
            }
            catch
            {
                MessageBox.Show("You don't have access to any accounts");
            }
        }

        public void updateUserLabels()
        {
            lblUsername.Text = CurrentUser.Name;
            lblSin.Text = CurrentUser.SIN;
        }

        public void updateAccountLabels()
        {
            lblBalance.Text = String.Format("{0:C}", currentAccount.Balance); ;
            lblAccountType.Text = currentAccount.Number.Substring(0, 2);
            //System.Type type = currentAccount.GetType();
            lblAccountType.Text = currentAccount.GetAccountType() + " Account";
            lblLowestBalanceData.Text = String.Format("{0:C}", currentAccount.LowestBalance);
            string accountType = currentAccount.GetAccountType();
            if (accountType == "Visa")
            {
                lblTransactionCostData.Text = "$ 0.00";
            }
            else if (accountType == "Checking")
            {
                CheckingAccount c = (CheckingAccount)currentAccount;
                lblTransactionCostData.Text = String.Format("{0:C}", c.getCostPerTransaction());
            }
            else if (accountType == "Savings")
            {
                SavingAccount s = (SavingAccount)currentAccount;
                lblTransactionCostData.Text = String.Format("{0:C}", s.getCostPerTransaction());
            }
            //lblTransactionCostData.Text = tcost.ToString();
        }

        private double getCostPerTransaction(Account a)
        {
            double costPerTransaction = 0.0;
            string accountType = a.Number.Substring(0, 2);
            if (accountType == "VS")
            {
                //costPerTransaction = VisaAccount.COST
            }

            return costPerTransaction;
        }


        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void picTransactions_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPageTransactions);
        }

        private void picHolders_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPageHolders);
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            Console.WriteLine(e.TabPage);
            string tabName = e.TabPage.Name;

            if (tabName == "tabPageTransactions")
            {
                updateTransactions();
            }
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnNewAccount_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4(this);
            this.Enabled = false;
            f4.Show();
        }

        private void picAddHolder_Click(object sender, EventArgs e)
        {
            if (currentAccount == null)
            {
                MessageBox.Show("Select an account first");
            }
            else
            {
                Form5 f5 = new Form5(this, CurrentUser, currentAccount);
                this.Enabled = false;
                f5.Show();
            }
        }

        private void Form2_EnabledChanged(object sender, EventArgs e)
        {
            updateAccountLabels();
            updateTransactions();
            updateHolders();
        }

        private void picMonthlyReports_Click(object sender, EventArgs e)
        {
            if (currentAccount == null)
            {
                MessageBox.Show("Select an account first");
            }
            else
            {
                Form8 f8 = new Form8(this, CurrentUser, currentAccount);
                this.Enabled = false;
                f8.Show();
            }
        }

        private void picDeposit_Click(object sender, EventArgs e)
        {
            if (currentAccount == null)
            {
                MessageBox.Show("Select an account first");
            }
            else
            {
                Form6 f6 = new Form6(this, CurrentUser, currentAccount);
                this.Enabled = false;
                f6.Show();
            }
        }

        private void picWithdraw_Click(object sender, EventArgs e)
        {
            if (currentAccount == null)
            {
                MessageBox.Show("Select an account first");
            }
            else
            {
                Form7 f7 = new Form7(this, CurrentUser, currentAccount);
                this.Enabled = false;
                f7.Show();
            }
        }





        /*
        private void btnChequeDeposit_Click(object sender, EventArgs e)
        {
            Chequeing = Convert.ToDouble(txtCheque.Text);

            CheckingAccount c = (CheckingAccount)Bank.GetAccount("CK-100005");
            c.Deposit(Chequeing, p);
        }

        private void btnChequeWithdrawl_Click(object sender, EventArgs e)
        {
            Chequeing = Convert.ToDouble(txtCheque.Text);

            CheckingAccount c = (CheckingAccount)Bank.GetAccount("CK-100005");

            c.Withdraw(Chequeing, p);
        }

        private void btnSavingDeposit_Click(object sender, EventArgs e)
        {
            Savings = Convert.ToDouble(txtSaving.Text);

            SavingAccount b = (SavingAccount)Bank.GetAccount("SV-100002");
            b.Deposit(Savings, p);
        }

        private void btnSavingWithdrawl_Click(object sender, EventArgs e)
        {
            Savings = Convert.ToDouble(txtSaving.Text);

            SavingAccount b = (SavingAccount)Bank.GetAccount("SV-100002");
            b.Withdraw(Savings, p);
        }

        private void btnVisaPayment_Click(object sender, EventArgs e)
        {
            Visa = Convert.ToDouble(txtVisa.Text);

            VisaAccount a = (VisaAccount)Bank.GetAccount("VS-100000");
            a.DoPayment(Visa, p);
        }

        private void btnCashAdvance_Click(object sender, EventArgs e)
        {
            Visa = Convert.ToDouble(txtVisa.Text);

            VisaAccount a = (VisaAccount)Bank.GetAccount("VS-100000");
            a.DoPurchase(Visa, p);
        }
         * */
    }
}
