﻿namespace Account_GUI
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.picTransactions = new System.Windows.Forms.PictureBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblSin = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblLowestBalanceData = new System.Windows.Forms.Label();
            this.lblLowestBalance = new System.Windows.Forms.Label();
            this.lblTransactionCostData = new System.Windows.Forms.Label();
            this.lblTransactionCost = new System.Windows.Forms.Label();
            this.picWithdraw = new System.Windows.Forms.PictureBox();
            this.picDeposit = new System.Windows.Forms.PictureBox();
            this.picMonthlyReports = new System.Windows.Forms.PictureBox();
            this.picLogout = new System.Windows.Forms.PictureBox();
            this.picHolders = new System.Windows.Forms.PictureBox();
            this.lblAccountType = new System.Windows.Forms.Label();
            this.btnNewAccount = new System.Windows.Forms.Button();
            this.lblBalance = new System.Windows.Forms.Label();
            this.cboxAccounts = new System.Windows.Forms.ComboBox();
            this.tabPageTransactions = new System.Windows.Forms.TabPage();
            this.dataGridTransactions = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPageHolders = new System.Windows.Forms.TabPage();
            this.dataGridHolders = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.picAddHolder = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.picTransactions)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWithdraw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDeposit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMonthlyReports)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHolders)).BeginInit();
            this.tabPageTransactions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTransactions)).BeginInit();
            this.tabPageHolders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHolders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAddHolder)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // picTransactions
            // 
            this.picTransactions.BackColor = System.Drawing.Color.Transparent;
            this.picTransactions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picTransactions.Image = ((System.Drawing.Image)(resources.GetObject("picTransactions.Image")));
            this.picTransactions.Location = new System.Drawing.Point(381, 32);
            this.picTransactions.Name = "picTransactions";
            this.picTransactions.Size = new System.Drawing.Size(50, 42);
            this.picTransactions.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picTransactions.TabIndex = 0;
            this.picTransactions.TabStop = false;
            this.picTransactions.Click += new System.EventHandler(this.picTransactions_Click);
            // 
            // lblUsername
            // 
            this.lblUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.Location = new System.Drawing.Point(59, 36);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(157, 29);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Username";
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUsername.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblSin
            // 
            this.lblSin.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSin.Location = new System.Drawing.Point(60, 75);
            this.lblSin.Name = "lblSin";
            this.lblSin.Size = new System.Drawing.Size(152, 24);
            this.lblSin.TabIndex = 1;
            this.lblSin.Text = "SIN";
            this.lblSin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblLowestBalanceData);
            this.panel1.Controls.Add(this.lblLowestBalance);
            this.panel1.Controls.Add(this.lblTransactionCostData);
            this.panel1.Controls.Add(this.lblTransactionCost);
            this.panel1.Controls.Add(this.picWithdraw);
            this.panel1.Controls.Add(this.picDeposit);
            this.panel1.Controls.Add(this.picMonthlyReports);
            this.panel1.Controls.Add(this.picLogout);
            this.panel1.Controls.Add(this.picHolders);
            this.panel1.Controls.Add(this.lblAccountType);
            this.panel1.Controls.Add(this.picTransactions);
            this.panel1.Controls.Add(this.btnNewAccount);
            this.panel1.Controls.Add(this.lblBalance);
            this.panel1.Controls.Add(this.cboxAccounts);
            this.panel1.Controls.Add(this.lblSin);
            this.panel1.Controls.Add(this.lblUsername);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1056, 498);
            this.panel1.TabIndex = 2;
            // 
            // lblLowestBalanceData
            // 
            this.lblLowestBalanceData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLowestBalanceData.Location = new System.Drawing.Point(177, 280);
            this.lblLowestBalanceData.Name = "lblLowestBalanceData";
            this.lblLowestBalanceData.Size = new System.Drawing.Size(92, 21);
            this.lblLowestBalanceData.TabIndex = 16;
            this.lblLowestBalanceData.Text = "0.00";
            this.lblLowestBalanceData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLowestBalance
            // 
            this.lblLowestBalance.AutoSize = true;
            this.lblLowestBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLowestBalance.Location = new System.Drawing.Point(8, 280);
            this.lblLowestBalance.Name = "lblLowestBalance";
            this.lblLowestBalance.Size = new System.Drawing.Size(111, 17);
            this.lblLowestBalance.TabIndex = 15;
            this.lblLowestBalance.Text = "Lowest Balance:";
            // 
            // lblTransactionCostData
            // 
            this.lblTransactionCostData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionCostData.Location = new System.Drawing.Point(180, 306);
            this.lblTransactionCostData.Name = "lblTransactionCostData";
            this.lblTransactionCostData.Size = new System.Drawing.Size(89, 23);
            this.lblTransactionCostData.TabIndex = 14;
            this.lblTransactionCostData.Text = "0.00";
            this.lblTransactionCostData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTransactionCostData.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblTransactionCost
            // 
            this.lblTransactionCost.AutoSize = true;
            this.lblTransactionCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTransactionCost.Location = new System.Drawing.Point(8, 312);
            this.lblTransactionCost.Name = "lblTransactionCost";
            this.lblTransactionCost.Size = new System.Drawing.Size(119, 17);
            this.lblTransactionCost.TabIndex = 13;
            this.lblTransactionCost.Text = "Transaction Cost:";
            // 
            // picWithdraw
            // 
            this.picWithdraw.BackColor = System.Drawing.Color.Transparent;
            this.picWithdraw.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picWithdraw.Image = ((System.Drawing.Image)(resources.GetObject("picWithdraw.Image")));
            this.picWithdraw.Location = new System.Drawing.Point(976, 34);
            this.picWithdraw.Name = "picWithdraw";
            this.picWithdraw.Size = new System.Drawing.Size(50, 42);
            this.picWithdraw.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picWithdraw.TabIndex = 10;
            this.picWithdraw.TabStop = false;
            this.picWithdraw.Click += new System.EventHandler(this.picWithdraw_Click);
            // 
            // picDeposit
            // 
            this.picDeposit.BackColor = System.Drawing.Color.Transparent;
            this.picDeposit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picDeposit.Image = ((System.Drawing.Image)(resources.GetObject("picDeposit.Image")));
            this.picDeposit.Location = new System.Drawing.Point(903, 34);
            this.picDeposit.Name = "picDeposit";
            this.picDeposit.Size = new System.Drawing.Size(50, 42);
            this.picDeposit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDeposit.TabIndex = 9;
            this.picDeposit.TabStop = false;
            this.picDeposit.Click += new System.EventHandler(this.picDeposit_Click);
            // 
            // picMonthlyReports
            // 
            this.picMonthlyReports.BackColor = System.Drawing.Color.Transparent;
            this.picMonthlyReports.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picMonthlyReports.Image = ((System.Drawing.Image)(resources.GetObject("picMonthlyReports.Image")));
            this.picMonthlyReports.Location = new System.Drawing.Point(471, 34);
            this.picMonthlyReports.Name = "picMonthlyReports";
            this.picMonthlyReports.Size = new System.Drawing.Size(42, 40);
            this.picMonthlyReports.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMonthlyReports.TabIndex = 8;
            this.picMonthlyReports.TabStop = false;
            this.picMonthlyReports.Click += new System.EventHandler(this.picMonthlyReports_Click);
            // 
            // picLogout
            // 
            this.picLogout.BackColor = System.Drawing.Color.Transparent;
            this.picLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picLogout.Image = ((System.Drawing.Image)(resources.GetObject("picLogout.Image")));
            this.picLogout.Location = new System.Drawing.Point(989, 454);
            this.picLogout.Name = "picLogout";
            this.picLogout.Size = new System.Drawing.Size(37, 31);
            this.picLogout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogout.TabIndex = 7;
            this.picLogout.TabStop = false;
            this.picLogout.Click += new System.EventHandler(this.picLogout_Click);
            // 
            // picHolders
            // 
            this.picHolders.BackColor = System.Drawing.Color.Transparent;
            this.picHolders.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picHolders.Image = ((System.Drawing.Image)(resources.GetObject("picHolders.Image")));
            this.picHolders.Location = new System.Drawing.Point(296, 32);
            this.picHolders.Name = "picHolders";
            this.picHolders.Size = new System.Drawing.Size(48, 42);
            this.picHolders.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picHolders.TabIndex = 6;
            this.picHolders.TabStop = false;
            this.picHolders.Click += new System.EventHandler(this.picHolders_Click);
            // 
            // lblAccountType
            // 
            this.lblAccountType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountType.Location = new System.Drawing.Point(63, 217);
            this.lblAccountType.Name = "lblAccountType";
            this.lblAccountType.Size = new System.Drawing.Size(157, 20);
            this.lblAccountType.TabIndex = 5;
            this.lblAccountType.Text = "Account Type";
            this.lblAccountType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNewAccount
            // 
            this.btnNewAccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewAccount.Location = new System.Drawing.Point(229, 123);
            this.btnNewAccount.Name = "btnNewAccount";
            this.btnNewAccount.Size = new System.Drawing.Size(26, 23);
            this.btnNewAccount.TabIndex = 4;
            this.btnNewAccount.Text = "+";
            this.btnNewAccount.UseVisualStyleBackColor = true;
            this.btnNewAccount.Click += new System.EventHandler(this.btnNewAccount_Click);
            // 
            // lblBalance
            // 
            this.lblBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.Location = new System.Drawing.Point(63, 172);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(157, 26);
            this.lblBalance.TabIndex = 3;
            this.lblBalance.Text = "Balance";
            this.lblBalance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cboxAccounts
            // 
            this.cboxAccounts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboxAccounts.FormattingEnabled = true;
            this.cboxAccounts.Location = new System.Drawing.Point(55, 123);
            this.cboxAccounts.Name = "cboxAccounts";
            this.cboxAccounts.Size = new System.Drawing.Size(157, 21);
            this.cboxAccounts.TabIndex = 2;
            this.cboxAccounts.SelectedValueChanged += new System.EventHandler(this.cboxAccounts_SelectedValueChanged);
            // 
            // tabPageTransactions
            // 
            this.tabPageTransactions.Controls.Add(this.label5);
            this.tabPageTransactions.Controls.Add(this.dataGridTransactions);
            this.tabPageTransactions.Location = new System.Drawing.Point(4, 5);
            this.tabPageTransactions.Name = "tabPageTransactions";
            this.tabPageTransactions.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTransactions.Size = new System.Drawing.Size(738, 358);
            this.tabPageTransactions.TabIndex = 0;
            this.tabPageTransactions.Text = "Transactions";
            this.tabPageTransactions.UseVisualStyleBackColor = true;
            // 
            // dataGridTransactions
            // 
            this.dataGridTransactions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridTransactions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridTransactions.Location = new System.Drawing.Point(3, 75);
            this.dataGridTransactions.Name = "dataGridTransactions";
            this.dataGridTransactions.Size = new System.Drawing.Size(732, 280);
            this.dataGridTransactions.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 26);
            this.label5.TabIndex = 1;
            this.label5.Text = "Transactions";
            // 
            // tabPageHolders
            // 
            this.tabPageHolders.Controls.Add(this.picAddHolder);
            this.tabPageHolders.Controls.Add(this.label6);
            this.tabPageHolders.Controls.Add(this.dataGridHolders);
            this.tabPageHolders.Location = new System.Drawing.Point(4, 5);
            this.tabPageHolders.Name = "tabPageHolders";
            this.tabPageHolders.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHolders.Size = new System.Drawing.Size(738, 341);
            this.tabPageHolders.TabIndex = 1;
            this.tabPageHolders.Text = "Holders";
            this.tabPageHolders.UseVisualStyleBackColor = true;
            // 
            // dataGridHolders
            // 
            this.dataGridHolders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridHolders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridHolders.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridHolders.Location = new System.Drawing.Point(3, 52);
            this.dataGridHolders.Name = "dataGridHolders";
            this.dataGridHolders.Size = new System.Drawing.Size(732, 286);
            this.dataGridHolders.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(172, 26);
            this.label6.TabIndex = 2;
            this.label6.Text = "Account Holders";
            // 
            // picAddHolder
            // 
            this.picAddHolder.BackColor = System.Drawing.Color.Transparent;
            this.picAddHolder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picAddHolder.Image = ((System.Drawing.Image)(resources.GetObject("picAddHolder.Image")));
            this.picAddHolder.Location = new System.Drawing.Point(688, 12);
            this.picAddHolder.Name = "picAddHolder";
            this.picAddHolder.Size = new System.Drawing.Size(31, 26);
            this.picAddHolder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAddHolder.TabIndex = 13;
            this.picAddHolder.TabStop = false;
            this.picAddHolder.Click += new System.EventHandler(this.picAddHolder_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPageHolders);
            this.tabControl1.Controls.Add(this.tabPageTransactions);
            this.tabControl1.ItemSize = new System.Drawing.Size(0, 1);
            this.tabControl1.Location = new System.Drawing.Point(285, 94);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(746, 350);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 3;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1056, 498);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "World Bank";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.EnabledChanged += new System.EventHandler(this.Form2_EnabledChanged);
            ((System.ComponentModel.ISupportInitialize)(this.picTransactions)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWithdraw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDeposit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMonthlyReports)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHolders)).EndInit();
            this.tabPageTransactions.ResumeLayout(false);
            this.tabPageTransactions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridTransactions)).EndInit();
            this.tabPageHolders.ResumeLayout(false);
            this.tabPageHolders.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridHolders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAddHolder)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picTransactions;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblSin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.ComboBox cboxAccounts;
        private System.Windows.Forms.Label lblAccountType;
        private System.Windows.Forms.Button btnNewAccount;
        private System.Windows.Forms.PictureBox picHolders;
        private System.Windows.Forms.PictureBox picMonthlyReports;
        private System.Windows.Forms.PictureBox picLogout;
        private System.Windows.Forms.PictureBox picWithdraw;
        private System.Windows.Forms.PictureBox picDeposit;
        private System.Windows.Forms.Label lblTransactionCost;
        private System.Windows.Forms.Label lblTransactionCostData;
        private System.Windows.Forms.Label lblLowestBalanceData;
        private System.Windows.Forms.Label lblLowestBalance;
        private System.Windows.Forms.TabPage tabPageTransactions;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridTransactions;
        private System.Windows.Forms.TabPage tabPageHolders;
        private System.Windows.Forms.PictureBox picAddHolder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridHolders;
        private System.Windows.Forms.TabControl tabControl1;


    }
}