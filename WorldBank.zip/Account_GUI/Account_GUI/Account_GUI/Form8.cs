﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form8 : Form
    {
        private Form2 mainF = null;

        Person CurrentUser = null;
        Account CurrentAccount = null;

        public Form8(Form2 mainForm, Person currentUser, Account currentAccount)
        {
            CurrentUser = currentUser;
            CurrentAccount = currentAccount;
            mainF = mainForm;
            InitializeComponent();

            updateAccount();
        }


        private void updateAccount()
        {
            List<string> accounts = new List<string>();
            accounts.Add(CurrentAccount.Number);
            cBoxAccounts.DataSource = null;
            cBoxAccounts.DataSource = accounts;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            closeForm();
        }

        private void closeForm()
        {
            mainF.Enabled = true;
            this.Close();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            CurrentAccount.PrepareMonthlyReport();
            MessageBox.Show("Monthly Report Prepared");

            closeForm();
        }
    }
}
