﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form5 : Form
    {
        private Form2 mainF = null;

        Dictionary<string, Person> allUsersDict;
        Person CurrentUser = null;
        Account CurrentAccount = null;

        public Form5(Form2 mainForm, Person currentUser, Account currentAccount)
        {
            CurrentUser = currentUser;
            CurrentAccount = currentAccount;
            mainF = mainForm;
            InitializeComponent();

            updateListOfUsers();
            updateAccount();
        }


        private void updateAccount()
        {
            List<string> accounts = new List<string>();
            accounts.Add(CurrentAccount.Number);
            cBoxAccounts.DataSource = null;
            cBoxAccounts.DataSource = accounts;
        }

        private void updateListOfUsers()
        {
            List<Person> allUsers = new List<Person>();
            List<string> allUsersNames = new List<string>();
            allUsersDict = new Dictionary<string, Person>();

            cBoxUsers.DataSource = null;

            try
            {
                allUsers = Bank.GetAllUsers();

                foreach (Person p in allUsers)
                {
                    if (p.Name == CurrentUser.Name || CurrentAccount.IsHolder(p.Name))
                    {
                        continue;
                    }
                    allUsersNames.Add(p.Name);
                    allUsersDict.Add(p.Name, p);
                }
                cBoxUsers.DataSource = allUsersNames;
            }
            catch
            {
                MessageBox.Show("Error!");
            }
        }

        private void closeForm()
        {
            mainF.Enabled = true;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            closeForm();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string personAddName = cBoxUsers.SelectedItem.ToString();
            Person p = allUsersDict[personAddName];

            CurrentAccount.AddUser(p);

            MessageBox.Show(p.Name + " Added to the account as a holder!");

            closeForm();
        }
    }
}
