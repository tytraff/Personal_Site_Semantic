﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form3 : Form
    {
        private Form1 mainF = null;

        public Form3(Form1 mainForm)
        {
            mainF = mainForm;
            InitializeComponent();
        }

        private void regButton_Click(object sender, EventArgs e)
        {
            if (textBoxName.Text.Length == 0 || textBoxSin.Text.Length == 0)
            {
                MessageBox.Show("Enter your name and SIN");
            }
            else
            {
                string name = textBoxName.Text;
                string SIN = textBoxSin.Text;
                Person p = new Person(name, SIN);

                try
                {
                    Bank.AddPerson(p);
                    MessageBox.Show("Registered!");
                    mainF.Enabled = true;
                    this.Close();
                }
                catch (Exception exc)
                {
                    MessageBox.Show("Name already exists");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            mainF.Enabled = true;
            this.Close();
        }
    }
}
