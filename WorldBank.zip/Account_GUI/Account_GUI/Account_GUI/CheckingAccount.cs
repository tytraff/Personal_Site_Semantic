﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Account_GUI
{
    class CheckingAccount : Account
    {
        static private double COST_PER_TRANSACTION = 0.05;
        static private double INTEREST_RATE = 0.005;
        private bool HasOverdraft;


        public CheckingAccount(double balance = 0, bool hasOverDraft = false) 
            : base("CK-", balance)
        {
            HasOverdraft = hasOverDraft;
        }

        public double getCostPerTransaction()
        {
            return CheckingAccount.COST_PER_TRANSACTION;
        }

        public new void Deposit(double amount, Person person)
        {
            bool isHolder = this.IsHolder(person.Name);

            base.Deposit(amount, person);

            /*if (isHolder)
            {
                base.Deposit(amount, person);
            }
            else
            {
                throw new Exception(AccountException.NAME_NOT_ASSOCIATED_WITH_ACCOUNT); // dont need?
            }*/
        }


        public void Withdraw(double amount, Person person)
        {
            bool isHolder = this.IsHolder(person.Name);

            if (isHolder == false)
            {
                throw new AccountException(AccountException.NAME_NOT_ASSOCIATED_WITH_ACCOUNT);
            }
            else if (person.IsAuthenticated == false)
            {
                throw new AccountException(AccountException.USER_NOT_LOGGED_IN);
            }
            else if ((amount > Balance) && (HasOverdraft == false))
            {
                throw new AccountException(AccountException.NO_OVERDRAFT);
            }
            else
            {
                base.Deposit(amount * -1, person);
            }
        }


        public override void PrepareMonthlyReport()
        {
            double serviceCharge = transactions.Count * COST_PER_TRANSACTION;
            double interest = Balance * (INTEREST_RATE / 12);

            //Console.WriteLine("{0}, {1}, {2:c4}", serviceCharge, interest, Balance);

            Balance = (Balance + interest) - serviceCharge;

            transactions.Clear();
        }
    }
}
