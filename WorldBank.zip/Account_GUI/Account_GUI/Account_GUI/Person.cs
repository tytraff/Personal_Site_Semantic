﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Account_GUI
{
    public class Person
    {
        private string password;
        public readonly string SIN;

        public bool IsAuthenticated { get; private set; }
        public string Name { get; private set; }
        
        public Person(string name, string sin)
        {
            Name = name;
            SIN = sin;
            password = sin.Substring(0, 3);
        } 

        public void Login(string password)
        {
            if (this.password == password)
            {
                IsAuthenticated = true;
            }
            else
            {
                //IsAuthenticated = false;
                throw new AccountException(AccountException.PASSWORD_INCORRECT);
            }
        }

        public void Logout()
        {
            IsAuthenticated = false;
        }

        public override string ToString()
        {
            string formatString = "";

            formatString = String.Format("Name: {0} | {1}Authenticated", Name, IsAuthenticated ? "" : "NOT ");

            return formatString;
        }
    }
}
