﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Account_GUI
{
    class AccountException : Exception
    {
        public const string ACCOUNT_DOES_NOT_EXIST = "Account does not exist";
        public const string CREDIT_LIMIT_HAS_BEEN_EXCEEDED ="Credit Limit Has Been Exceeded";
        public const string NAME_NOT_ASSOCIATED_WITH_ACCOUNT = "Name Not Associated With Account";
        public const string NO_OVERDRAFT = "No Overdraft Available";
        public const string PASSWORD_INCORRECT = "Password Incorrect";
        public const string USER_DOES_NOT_EXIST = "User Does Not Exist";
        public const string USER_NOT_LOGGED_IN = "User Not Logged In";

        public AccountException() : base() {}

        public AccountException(string type) : base(type) {}
    }
}
