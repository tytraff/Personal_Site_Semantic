﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Account_GUI
{
    public partial class Form4 : Form
    {
        private Form2 mainF = null;

        public Form4(Form2 mainForm)
        {
            mainF = mainForm;
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            mainF.Enabled = true;
        }

        private void closeForm()
        {
            this.Close();
            mainF.Enabled = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
