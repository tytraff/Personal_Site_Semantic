﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Account_GUI
{
    class SavingAccount : Account
    {
        static private double COST_PER_TRANSACTION = 0.05;
        static private double INTEREST_RATE = 0.015;


        public SavingAccount(double balance = 0) : base("SV-", balance) {}


        public new void Deposit(double amount, Person person)
        {
            bool isHolder = this.IsHolder(person.Name);

            base.Deposit(amount, person);

            /*if (isHolder)
            {
                base.Deposit(amount, person);
            }
            else
            {
                //throw new Exception(AccountException.NAME_NOT_ASSOCIATED_WITH_ACCOUNT); //Don't need this for savings? or for deposit()?
            }*/
        }

        public double getCostPerTransaction()
        {
            return SavingAccount.COST_PER_TRANSACTION;
        }

        public void Withdraw(double amount, Person person) // two withdraw functions in assignment?
        {
            bool isHolder = this.IsHolder(person.Name);

            if (isHolder == false)
            {
                throw new AccountException(AccountException.NAME_NOT_ASSOCIATED_WITH_ACCOUNT);
            }
            else if (person.IsAuthenticated == false)
            {
                throw new AccountException(AccountException.USER_NOT_LOGGED_IN);
            }
            else if (amount > Balance)
            {
                throw new AccountException(AccountException.CREDIT_LIMIT_HAS_BEEN_EXCEEDED);
            }
            else
            {
                base.Deposit(amount * -1, person);
            }
        }


        public override void PrepareMonthlyReport()
        {
            double serviceCharge = transactions.Count * COST_PER_TRANSACTION;
            double interest = Balance * (INTEREST_RATE / 12);

            Balance = (Balance + interest) - serviceCharge;

            transactions.Clear();
        }
    }
}
