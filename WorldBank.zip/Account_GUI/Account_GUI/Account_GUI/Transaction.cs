﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Account_GUI
{
    public class Transaction
    {
        public string AccountNumber { get; private set; }
        public double Amount { get; private set; }
        public double EndBalance { get; private set; }
        public Person Originator { get; private set; }
        public DateTime Time { get; private set; }

        public Transaction(string accountNumber, double amount, double endBalance, Person person, DateTime time)
        {
            AccountNumber = accountNumber;
            Amount = amount;
            EndBalance = endBalance;
            Originator = person;
            Time = time;
        }

        public override string ToString()
        {
            string formatString = "";
            bool isDeposit = Amount >= 0;

            formatString = String.Format("{0} {1} {2:C} at {3} {4} account {5}.", Originator.Name, isDeposit ? "DEPOSITED" : "WITHDREW", Math.Abs(Amount), 
                Time.ToShortTimeString(), isDeposit ? "to" : "from" , AccountNumber);

            return formatString;
        }
    }
}
